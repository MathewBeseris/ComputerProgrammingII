class THTableMoney extends BlackJack{
	
}