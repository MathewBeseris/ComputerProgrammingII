class THWallet extends Blackjack{
	
}