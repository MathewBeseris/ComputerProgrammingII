class BJTableMoney extends BlackJack{
	
}