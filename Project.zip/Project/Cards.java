public class Cards {
	String[][] cards = new String[][]{
	/*♤*/	{"Ace", "2", "3"},
		{"Ace", "2" }
	}
	String[0][1];
}