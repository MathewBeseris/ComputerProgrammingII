class BJWallet extends Blackjack{
	
}